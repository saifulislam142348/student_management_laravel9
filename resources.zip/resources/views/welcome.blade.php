@extends('layouts.layout')

@section('content')


   

<div class="container">
 


   <li><a href="{{route('student')}}" class="list-group-item text-danger btn btn-light "> student</a>
   <li><a href="{{route('admin')}}" class="list-group-item text-danger btn  btn-light">Admin</a>
   </li>  
   
  

  



    
       
       
       
  

 


</div>

@endsection